<div class="footer bg-light">
    <div class="container">



        <div class="row">
            <div class="col-12">
                <div class="copyright">
                    <h2>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://www.facebook.com/magdy.nabil.1426/" target="_blank" >Magdy Nabil</a>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </h2>
                    </br>
                    <h1 class="text-warning font-weight-bold">01023230428</h1>
                </div>
            </div>
        </div>
    </div>
</div>